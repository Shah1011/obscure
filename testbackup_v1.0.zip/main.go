/*
Copyright © 2025 NAME HERE <EMAIL ADDRESS>
*/
package main

import (
	"github.com/shah1011/obscure/cmd"
)

func main() {
	cmd.Execute()
}
